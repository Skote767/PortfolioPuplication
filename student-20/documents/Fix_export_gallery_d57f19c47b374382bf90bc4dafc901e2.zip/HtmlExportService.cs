using PortfolioConstruct.Models;
using System.Text;

namespace PortfolioConstruct.Service
{
    public class HtmlExportService
    {
        public byte[] GenerateHtmlZip(Portfolio portfolio, string userEmail)
        {
            var html = GenerateHtml(portfolio, userEmail);
            var css  = GenerateCss(portfolio);
            var js   = GenerateJs();

            using var ms = new MemoryStream();
            using (var zip = new System.IO.Compression.ZipArchive(ms, System.IO.Compression.ZipArchiveMode.Create, true))
            {
                WriteEntry(zip, "index.html", html);
                WriteEntry(zip, "style.css",  css);
                WriteEntry(zip, "script.js",  js);

                // Копируем ВСЕ файлы, упомянутые в блоках: одиночные фото, фото из галерей, документы
                foreach (var section in portfolio.Sections)
                {
                    foreach (var block in section.Blocks)
                    {
                        // Обычное изображение
                        if (block.Type == "image" && !string.IsNullOrWhiteSpace(block.Content))
                        {
                            CopyFileToZip(zip, block.Content, "images");
                        }
                        // Документ — Content хранится как "путь|оригинальное_имя"
                        else if (block.Type == "document" && !string.IsNullOrWhiteSpace(block.Content))
                        {
                            var docPath = block.Content.Split('|')[0];
                            CopyFileToZip(zip, docPath, "documents");
                        }
                        // Галерея — несколько фото в GalleryImages
                        else if (block.Type == "gallery" && block.GalleryImages.Any())
                        {
                            foreach (var img in block.GalleryImages)
                            {
                                CopyFileToZip(zip, img.ImagePath, "images");
                            }
                        }
                    }
                }
            }

            ms.Position = 0;
            return ms.ToArray();
        }

        // Копирует один файл с диска в архив, избегая дублирования записей с одинаковым именем
        private void CopyFileToZip(System.IO.Compression.ZipArchive zip, string webPath, string folderInZip)
        {
            if (string.IsNullOrWhiteSpace(webPath)) return;

            // webPath вида "/uploads/abc123.jpg" -> локальный файл "wwwroot/uploads/abc123.jpg"
            var localPath = Path.Combine("wwwroot", webPath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(localPath)) return;

            var entryName = $"{folderInZip}/{Path.GetFileName(localPath)}";

            // Если такой файл уже добавлен в архив (например то же фото в нескольких блоках) — пропускаем
            if (zip.GetEntry(entryName) != null) return;

            var entry = zip.CreateEntry(entryName);
            using var entryStream = entry.Open();
            using var fileStream  = File.OpenRead(localPath);
            fileStream.CopyTo(entryStream);
        }

        // ===== HTML =====
        private string GenerateHtml(Portfolio portfolio, string userEmail)
        {
            var sb      = new StringBuilder();
            var bgColor = portfolio.DesignSetting?.Color ?? "#f0f4f8";
            var font    = portfolio.DesignSetting?.Font  ?? "Arial";

            sb.AppendLine("<!DOCTYPE html>");
            sb.AppendLine("<html lang=\"ru\">");
            sb.AppendLine("<head>");
            sb.AppendLine("  <meta charset=\"UTF-8\">");
            sb.AppendLine("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            sb.AppendLine($"  <title>Портфолио — {userEmail}</title>");
            sb.AppendLine("  <link rel=\"stylesheet\" href=\"style.css\">");
            sb.AppendLine("</head>");
            sb.AppendLine($"<body style=\"background:{bgColor}; font-family:'{font}', sans-serif\">");

            sb.AppendLine("  <header class=\"portfolio-header\">");
            sb.AppendLine($"    <div><h1 class=\"portfolio-name\">{userEmail}</h1>");
            sb.AppendLine("    <p class=\"portfolio-sub\">Студенческое портфолио</p></div>");
            sb.AppendLine("  </header>");

            sb.AppendLine("  <nav class=\"portfolio-nav\" id=\"main-nav\">");
            bool first = true;
            foreach (var section in portfolio.Sections)
            {
                if (!section.Blocks.Any()) continue;
                var active = first ? " active" : "";
                sb.AppendLine($"    <button class=\"nav-btn{active}\" onclick=\"showSection('section-{section.Id}', this)\">{section.Title}</button>");
                first = false;
            }
            sb.AppendLine("  </nav>");

            sb.AppendLine("  <main class=\"portfolio-content\">");
            first = true;
            foreach (var section in portfolio.Sections)
            {
                if (!section.Blocks.Any()) continue;
                var display = first ? "block" : "none";
                sb.AppendLine($"    <section id=\"section-{section.Id}\" class=\"portfolio-section\" style=\"display:{display}\">");
                sb.AppendLine($"      <h2 class=\"section-heading\">{section.Title}</h2>");

                foreach (var block in section.Blocks)
                {
                    sb.AppendLine(RenderBlock(block));
                }

                sb.AppendLine("    </section>");
                first = false;
            }
            sb.AppendLine("  </main>");

            sb.AppendLine("  <script src=\"script.js\"></script>");
            sb.AppendLine("</body>");
            sb.AppendLine("</html>");

            return sb.ToString();
        }

        private string RenderBlock(Block block)
        {
            var caption = string.IsNullOrWhiteSpace(block.Caption) ? "" :
                $"<p class=\"block-caption\">{block.Caption}</p>";

            return block.Type switch
            {
                "text" => $"      <div class=\"block-text\" style=\"text-align:{block.TextAlign};font-size:{block.FontSize}px;color:{block.TextColor}\">{block.Content}</div>",

                "image" when !string.IsNullOrWhiteSpace(block.Content) =>
                    $"      <div class=\"block-image\">" +
                    $"<img src=\"images/{Path.GetFileName(block.Content)}\" alt=\"{block.Caption ?? "Изображение"}\">" +
                    $"{caption}</div>",

                "link" when !string.IsNullOrWhiteSpace(block.Content) =>
                    $"      <div class=\"block-link\">" +
                    (string.IsNullOrWhiteSpace(block.Caption) ? "" : $"<p class=\"link-label\">{block.Caption}</p>") +
                    $"<a href=\"{block.Content}\" target=\"_blank\">🔗 {block.Content}</a></div>",

                "document" when !string.IsNullOrWhiteSpace(block.Content) =>
                    RenderDocumentBlock(block),

                "gallery" when block.GalleryImages.Any() =>
                    RenderGalleryBlock(block),

                _ => ""
            };
        }

        // Документ: Content хранится как "путь|оригинальное_имя"
        private string RenderDocumentBlock(Block block)
        {
            var parts   = block.Content.Split('|');
            var docPath = "documents/" + Path.GetFileName(parts[0]);
            var docName = parts.Length > 1 ? parts[1] : Path.GetFileName(parts[0]);
            var caption = string.IsNullOrWhiteSpace(block.Caption) ? "" :
                $"<p class=\"doc-caption\">{block.Caption}</p>";

            return $"      <div class=\"block-document\">" +
                   $"<div class=\"doc-info\"><p class=\"doc-name\">📎 {docName}</p>{caption}</div>" +
                   $"<a class=\"btn-download\" href=\"{docPath}\" download target=\"_blank\">⬇ Скачать</a>" +
                   $"</div>";
        }

        // Галерея: несколько фото с простым JS-переключением (без зависимостей)
        private string RenderGalleryBlock(Block block)
        {
            var sb = new StringBuilder();
            var images = block.GalleryImages.OrderBy(g => g.SortOrder).ToList();
            var galleryId = $"gallery-{block.Id}";

            sb.Append($"      <div class=\"block-gallery\" id=\"{galleryId}\">");
            sb.Append("<div class=\"gallery-viewer\">");

            for (int i = 0; i < images.Count; i++)
            {
                var img = images[i];
                var displayStyle = i == 0 ? "block" : "none";
                var imgCaption = string.IsNullOrWhiteSpace(img.Caption) ? "" :
                    $"<p class=\"block-caption\">{img.Caption}</p>";

                sb.Append($"<div class=\"gallery-slide\" data-index=\"{i}\" style=\"display:{displayStyle}\">");
                sb.Append($"<img src=\"images/{Path.GetFileName(img.ImagePath)}\" alt=\"Фото {i + 1}\">");
                sb.Append(imgCaption);
                sb.Append("</div>");
            }

            sb.Append("</div>"); // .gallery-viewer

            if (images.Count > 1)
            {
                sb.Append($"<div class=\"gallery-controls\">");
                sb.Append($"<button class=\"gallery-arrow\" onclick=\"galleryMove('{galleryId}', -1)\">‹</button>");
                sb.Append($"<span class=\"gallery-counter\" id=\"{galleryId}-counter\">1 / {images.Count}</span>");
                sb.Append($"<button class=\"gallery-arrow\" onclick=\"galleryMove('{galleryId}', 1)\">›</button>");
                sb.Append("</div>");
            }

            sb.Append("</div>"); // .block-gallery

            return sb.ToString();
        }

        // ===== CSS =====
        private string GenerateCss(Portfolio portfolio)
        {
            var accent = portfolio.DesignSetting?.AccentColor ?? "#4f6ef7";
            return $@"
*, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

body {{
    min-height: 100vh;
    font-size: 16px;
    line-height: 1.6;
    color: #374151;
}}

.portfolio-header {{
    padding: 2rem 3rem;
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(6px);
    border-bottom: 3px solid {accent};
}}
.portfolio-name {{ font-size: 1.8rem; font-weight: 700; color: #1a1a2e; }}
.portfolio-sub  {{ color: #6b7280; font-size: 0.95rem; margin-top: 0.25rem; }}

.portfolio-nav {{
    display: flex;
    flex-wrap: wrap;
    gap: 0.25rem;
    padding: 0 2rem;
    background: rgba(255,255,255,0.7);
    border-bottom: 1px solid #e5e7eb;
    position: sticky;
    top: 0;
    z-index: 10;
}}
.nav-btn {{
    padding: 0.75rem 1.25rem;
    background: none;
    border: none;
    border-bottom: 3px solid transparent;
    color: #374151;
    font-size: 0.95rem;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.15s;
}}
.nav-btn:hover {{ color: {accent}; }}
.nav-btn.active {{ color: {accent}; border-bottom-color: {accent}; font-weight: 600; }}

.portfolio-content {{
    max-width: 800px;
    margin: 0 auto;
    padding: 2.5rem 2rem;
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}}

.section-heading {{
    font-size: 1.5rem;
    font-weight: 700;
    color: {accent};
    padding-bottom: 0.5rem;
    border-bottom: 2px solid {accent};
    margin-bottom: 1rem;
}}

.portfolio-section {{
    display: flex;
    flex-direction: column;
    gap: 1.25rem;
}}

.block-text {{
    background: rgba(255,255,255,0.85);
    border-radius: 12px;
    padding: 1.25rem 1.5rem;
    line-height: 1.7;
    white-space: pre-wrap;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}}

.block-image {{
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    background: white;
}}
.block-image img {{ width: 100%; display: block; }}

.block-caption {{
    padding: 0.6rem 1rem;
    font-size: 0.85rem;
    color: #6b7280;
    font-style: italic;
    text-align: center;
    background: white;
}}

.block-link {{
    background: rgba(255,255,255,0.85);
    border-radius: 12px;
    padding: 1rem 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}}
.link-label {{ font-size: 0.9rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem; }}
.block-link a {{ color: {accent}; text-decoration: none; word-break: break-all; }}
.block-link a:hover {{ text-decoration: underline; }}

/* Документы */
.block-document {{
    background: rgba(255,255,255,0.85);
    border-radius: 12px;
    padding: 1rem 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    flex-wrap: wrap;
}}
.doc-name {{ font-weight: 600; color: #1a1a2e; word-break: break-word; }}
.doc-caption {{ font-size: 0.85rem; color: #6b7280; margin-top: 0.25rem; }}
.btn-download {{
    background: {accent};
    color: white;
    padding: 0.55rem 1.1rem;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.9rem;
    white-space: nowrap;
}}

/* Галерея */
.block-gallery {{
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}}
.gallery-viewer {{ position: relative; }}
.gallery-slide img {{ width: 100%; display: block; max-height: 480px; object-fit: contain; background: #f9fafb; }}
.gallery-controls {{
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    padding: 0.75rem;
    background: white;
}}
.gallery-arrow {{
    width: 36px; height: 36px;
    border-radius: 50%;
    border: 1.5px solid #e5e7eb;
    background: white;
    font-size: 1.2rem;
    cursor: pointer;
    transition: background 0.15s;
}}
.gallery-arrow:hover {{ background: #f3f4f6; }}
.gallery-counter {{ font-size: 0.85rem; color: #6b7280; min-width: 50px; text-align: center; }}

@media (max-width: 600px) {{
    .portfolio-header {{ padding: 1.5rem; }}
    .portfolio-content {{ padding: 1.5rem 1rem; }}
    .portfolio-name {{ font-size: 1.4rem; }}
    .block-document {{ flex-direction: column; align-items: flex-start; }}
    .btn-download {{ width: 100%; text-align: center; }}
}}
";
        }

        // ===== JS =====
        private string GenerateJs() => @"
function showSection(sectionId, btn) {
    document.querySelectorAll('.portfolio-section').forEach(s => s.style.display = 'none');
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(sectionId).style.display = 'block';
    btn.classList.add('active');
    document.querySelector('.portfolio-content').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Переключение фото внутри одной галереи
function galleryMove(galleryId, direction) {
    const gallery = document.getElementById(galleryId);
    const slides = gallery.querySelectorAll('.gallery-slide');
    const counter = document.getElementById(galleryId + '-counter');

    let currentIndex = 0;
    slides.forEach((s, i) => { if (s.style.display !== 'none') currentIndex = i; });

    slides[currentIndex].style.display = 'none';
    let newIndex = (currentIndex + direction + slides.length) % slides.length;
    slides[newIndex].style.display = 'block';

    if (counter) counter.textContent = (newIndex + 1) + ' / ' + slides.length;
}
";

        private static void WriteEntry(System.IO.Compression.ZipArchive zip, string name, string content)
        {
            var entry = zip.CreateEntry(name);
            using var writer = new StreamWriter(entry.Open(), Encoding.UTF8);
            writer.Write(content);
        }
    }
}
